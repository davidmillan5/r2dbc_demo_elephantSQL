package com.reactive.elephantr2dbccrud;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrudWithR2dbcAndElephantSqlApplicationTests {

	@Test
	void contextLoads() {
	}

}
