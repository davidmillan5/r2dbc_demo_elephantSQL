package com.reactive.elephantr2dbccrud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CrudWithR2dbcAndElephantSqlApplication {

	public static void main(String[] args) {
		SpringApplication.run(CrudWithR2dbcAndElephantSqlApplication.class, args);
	}

}
